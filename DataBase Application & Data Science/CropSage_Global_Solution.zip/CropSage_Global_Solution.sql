DROP TABLE t_gs_produto CASCADE CONSTRAINTS;

DROP TABLE t_gs_solo CASCADE CONSTRAINTS;

DROP TABLE t_gs_usuario CASCADE CONSTRAINTS;

DROP TABLE t_gs_registro_log CASCADE CONSTRAINTS;

DROP TABLE t_gs_localizacao CASCADE CONSTRAINTS;


CREATE TABLE t_gs_produto (
    cd_produto NUMBER(5) primary key,
    nm_produto VARCHAR2(50) NOT NULL,
    ds_plantio VARCHAR2(50)
);


CREATE TABLE t_gs_usuario (
    cd_usuario    NUMBER(6) primary key,
    nm_usuario    VARCHAR2(50),
    ds_email      VARCHAR2(50),
    ds_senha      VARCHAR2(35)
);
commit;


CREATE TABLE t_gs_registro_log (
	cd_erro NUMBER(5), 
    nm_usuario varchar2(50),
    dt_ocorrencia DATE,
    ds_mensagem varchar2(50)
);
commit;

CREATE TABLE t_gs_localizacao (
    cd_localizacao NUMBER(3) PRIMARY KEY,
    fk_usuario_localizacao    references t_gs_usuario,
    ds_longitude   VARCHAR2(10) NOT NULL,
    ds_latitude    VARCHAR2(10) NOT NULL,
    nm_localizacao VARCHAR2(50) NOT NULL,
    ds_cep         VARCHAR2(8) 
);


CREATE TABLE t_gs_solo (
    cd_solo        NUMBER(6) primary key,
    fk_produto     references t_gs_produto,
    fk_usuario     references t_gs_usuario,
    fk_localizacao     references t_gs_localizacao,
    qt_nitrogenio  NUMBER(4) NOT NULL,
    qt_potassio    NUMBER(4) NOT NULL,
    qt_fosforo     NUMBER(4) NOT NULL,
    qt_temperatura NUMBER(2) NOT NULL,
    qt_umidade     NUMBER(10) NOT NULL,
    ds_ph          NUMBER(10) NOT NULL,
    ds_chuva       NUMBER(10) NOT NULL
);
commit;




----------------------COMANDOS SQL----------------------
--OBS: Para conseguir rodar as pesquisas os inserts em pl/sql precisam ser feitos
--com os inserts feitos, para facilitar pode apenas digitar o c?digo 1
-- quando pedir inform??es de algum c?digo :)


set serveroutpu on
set verify off

/*
C�digo em pl/sql que insere automaticamente as informa��es da tabela:
T_GS_PRODUTO
*/
BEGIN
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (1, 'Arroz', 'De Outubro (01/10) - Dezembro (31/12)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (2, 'Milho', 'De Setembro (25/09) - Novembro (01/11)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (3, 'Trigo', 'De Junho (01/06) - Agosto (31/08)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (4, 'Feij�o', 'De Janeiro (01/09) - Novembro (31/11)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (5, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (6, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (7, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (8, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (9, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (10, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
    INSERT INTO t_gs_produto (cd_produto, nm_produto, ds_produto, ds_plantio) VALUES (11, 'Batata', 'De Janeiro (01/01) - Junho (01/06)');
  COMMIT;
END;

select * from t_gs_produto;




/*
C�digo em pl/sql que insere automaticamente as informa��es da tabela:
T_GS_USUARIO
*/
BEGIN
  INSERT INTO t_gs_usuario (cd_usuario, nm_usuario, ds_email, ds_senha) 
  VALUES (1, 'Usu�rio 1', 'usuario1@example.com', 'senha1');
  
  INSERT INTO t_gs_usuario (cd_usuario, nm_usuario, ds_email, ds_senha) 
  VALUES (2, 'Usu�rio 2', 'usuario2@example.com', 'senha2');
  
  INSERT INTO t_gs_usuario (cd_usuario, nm_usuario, ds_email, ds_senha) 
  VALUES (3, 'Usu�rio 3', 'usuario3@example.com', 'senha3');
  
  INSERT INTO t_gs_usuario (cd_usuario, nm_usuario, ds_email, ds_senha) 
  VALUES (4, 'Usu�rio 4', 'usuario4@example.com', 'senha4');
  
  INSERT INTO t_gs_usuario (cd_usuario, nm_usuario, ds_email, ds_senha) 
  VALUES (5, 'Usu�rio 5', 'usuario5@example.com', 'senha5');
  
  COMMIT;
end;

select * from t_gs_usuario;




/*
C�digo em pl/sql que  as insere informa��es da tabela:
"T_GS_PRODUTO"
Essa tabela ir� pedir as informa��es do Usuario e verificar se ele j� existe, 
caso ele ja exista ir� dar um erro, esse erro ser� registrado na tabela
"T_GS_REGISTRO_LOG". Agora, caso esse usu�rio n�o exista ir� inserir
as informa��es na tabela T_GS_USUARIO
*/
DECLARE
  v_cd_usuario t_gs_usuario.cd_usuario%TYPE;
  v_nm_usuario t_gs_usuario.nm_usuario%TYPE;
  v_cd_erro t_gs_registro_log.cd_erro%TYPE;
BEGIN
  v_cd_usuario := &cd_usuario;
  BEGIN
    SELECT nm_usuario
    INTO v_nm_usuario
    FROM t_gs_usuario
    WHERE cd_usuario = v_cd_usuario;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_nm_usuario := NULL;
  END;

  IF v_nm_usuario IS NULL THEN
    v_nm_usuario := '&nm_usuario';
    INSERT INTO t_gs_usuario (cd_usuario, nm_usuario, ds_email, ds_senha)
    VALUES (v_cd_usuario, v_nm_usuario, '&ds_email', '&ds_senha');
  ELSE
    SELECT MAX(cd_erro) INTO v_cd_erro FROM t_gs_registro_log;
    v_cd_erro := COALESCE(v_cd_erro, 0) + 1;
    INSERT INTO t_gs_registro_log (cd_erro, nm_usuario, dt_ocorrencia, ds_mensagem)
    VALUES (v_cd_erro, v_nm_usuario, SYSDATE, 'Erro: Usuario ja cadastrado em nosso sistema');
       DBMS_OUTPUT.PUT_LINE('Usuario ja cadastrado no sistema');
  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Erro: ' || SQLERRM);
END;

select * from t_gs_usuario;
select * from t_gs_registro_log;



/*
C�digo em pl/sql que insere automaticamente as informa��es da tabela:
T_GS_LOCALIZACAO
*/
BEGIN
  INSERT INTO t_gs_localizacao (cd_localizacao, fk_usuario_localizacao, ds_longitude, ds_latitude, nm_localizacao, ds_cep)
  VALUES (1, 1, 'Long1', 'Latitude 1', 'Localiza��o 1', 'CEP 1');
  
  INSERT INTO t_gs_localizacao (cd_localizacao, fk_usuario_localizacao, ds_longitude, ds_latitude, nm_localizacao, ds_cep)
  VALUES (2, 2, 'Long2', 'Latitude 2', 'Localiza��o 2', 'CEP 2');
  
  INSERT INTO t_gs_localizacao (cd_localizacao, fk_usuario_localizacao, ds_longitude, ds_latitude, nm_localizacao, ds_cep)
  VALUES (3, 2, 'Long3', 'Latitude 3', 'Localiza��o 3', 'CEP 3');
  
  INSERT INTO t_gs_localizacao (cd_localizacao, fk_usuario_localizacao, ds_longitude, ds_latitude, nm_localizacao, ds_cep)
  VALUES (4, 2, 'Long4', 'Latitude 4', 'Localiza��o 4', 'CEP 4');
  
  INSERT INTO t_gs_localizacao (cd_localizacao, fk_usuario_localizacao, ds_longitude, ds_latitude, nm_localizacao, ds_cep)
  VALUES (5, 1, 'Long5', 'Latitude 5', 'Localiza��o 5', 'CEP 5');
  
  COMMIT;
END;
select * from t_gs_localizacao;

/*
C�digo em pl/sql que gera um relatorio de todas as localiza��es vinculadas 
a um usuario 
*/
DECLARE
    v_cd_usuario t_gs_usuario.cd_usuario%TYPE; 
    v_ds_localizacao t_gs_localizacao%ROWTYPE;
    CURSOR c_localizacoes IS
        SELECT *
        FROM t_gs_localizacao
        WHERE fk_usuario_localizacao = v_cd_usuario;
BEGIN
    v_cd_usuario := &cd_usuario; 
    OPEN c_localizacoes;
    LOOP
        FETCH c_localizacoes INTO v_ds_localizacao;
        EXIT WHEN c_localizacoes%NOTFOUND;
         DBMS_OUTPUT.PUT_LINE('------------------------------');
        DBMS_OUTPUT.PUT_LINE('CD_Localiza��o: ' || v_ds_localizacao.cd_localizacao);
        DBMS_OUTPUT.PUT_LINE('Longitude: ' || v_ds_localizacao.ds_longitude);
        DBMS_OUTPUT.PUT_LINE('Latitude: ' || v_ds_localizacao.ds_latitude);
        DBMS_OUTPUT.PUT_LINE('Nome LOcaliza��o: ' || v_ds_localizacao.nm_localizacao);
        DBMS_OUTPUT.PUT_LINE('CEP: ' || v_ds_localizacao.ds_cep);
        DBMS_OUTPUT.PUT_LINE('------------------------------');
    END LOOP;
    CLOSE c_localizacoes;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Erro ao exibir as localiza��es: ' || SQLERRM);
END;






/*
C�digo em pl/sql que insere automaticamente as informa��es da tabela:
T_GS_SOLO
*/
BEGIN
  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (1, 1, 1, 1, 1, 1, 25, 50, 6.5, 100);

  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (2, 1, 2, 2, 2, 2, 26, 52, 6.4, 85);

  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (3, 1, 3, 3, 3, 3, 27, 55, 6.3, 90);

  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (4, 1, 4, 4, 4, 4, 28, 58, 6.2, 95);

  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (5, 2, 5, 5, 5, 5, 29, 60, 6.1, 80);
  
  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (6, 2, 5, 5, 5, 5, 29, 60, 6.1, 80);
  
  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (7, 3, 5, 5, 5, 5, 29, 60, 6.1, 80);
  
  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (8, 4, 5, 5, 5, 5, 29, 60, 6.1, 80);
  
  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (9, 4, 5, 5, 5, 5, 29, 60, 6.1, 80);
  
  INSERT INTO t_gs_solo (cd_solo, fk_produto, fk_usuario, qt_nitrogenio, qt_potassio, qt_fosforo, qt_temperatura, qt_umidade, ds_ph, ds_chuva)
  VALUES (10, 5, 5, 5, 5, 5, 29, 60, 6.1, 80);

  COMMIT;
END;
select * from t_gs_solo;




/*
CC�digo em pl/sql que gera um relat�rio de quantos solos est�o 
plantados com um determinado produto
*/
DECLARE
  v_produto_codigo t_gs_produto.cd_produto%TYPE; 
  v_produto_nome   t_gs_produto.nm_produto%TYPE;
  v_total_solos    NUMBER := 0;  

  CURSOR c_solos IS
    SELECT s.cd_solo, p.nm_produto FROM t_gs_solo s
    JOIN t_gs_produto p ON s.fk_produto = p.cd_produto
    WHERE p.cd_produto = v_produto_codigo;

BEGIN
  v_produto_codigo := &codigo_produto;
  SELECT nm_produto INTO v_produto_nome
  FROM t_gs_produto
  WHERE cd_produto = v_produto_codigo;

  FOR r_solo IN c_solos LOOP
    v_total_solos := v_total_solos + 1;

    DBMS_OUTPUT.PUT_LINE('Solo ' || r_solo.cd_solo || ' est� plantado com ' || v_produto_nome);
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('Total de solos com o produto ' || v_produto_nome || ': ' || v_total_solos);
END;

